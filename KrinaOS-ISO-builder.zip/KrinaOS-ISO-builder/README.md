# KrinaOS ISO Builder — prototipo reproducible

Este repositorio prepara una **ISO de prueba basada en Ubuntu 24.04 LTS + XFCE**, con marca KrinaOS y el portal personal instalado. No es una ISO de Linux Mint y no pretende hacerse pasar por Mint. Se eligió una base Ubuntu porque el flujo automatizado puede construirse en GitHub Actions desde Android.

## Qué hace

- Configura una sesión XFCE ligera.
- Incluye el portal web en `/opt/krinaos-portal-personal`.
- Añade el acceso automático al portal después de iniciar sesión en el escritorio.
- No configura una contraseña predeterminada ni incluye contraseñas en el código.
- No formatea automáticamente discos.
- Genera un artefacto ISO mediante GitHub Actions, si el workflow termina correctamente.

## Limitaciones importantes

Este es un **prototipo de constructor**, no una ISO final verificada. No incluye todavía un instalador gráfico personalizado, la autenticación de red del portal ni subida/borrado remoto de archivos. La API de lectura se mantiene en localhost. No instala Discord ni Spotify en esta primera ISO; se pueden integrar después desde fuentes oficiales.

El flujo de GitHub Actions puede necesitar ajustes por cambios en los paquetes/repositorios y los límites de tiempo del runner. La ISO resultante debe probarse primero en una máquina virtual antes de instalarla en el ordenador real.

## Crear la ISO desde Android

1. Descarga este ZIP y descomprímelo.
2. Crea un repositorio nuevo en GitHub desde el navegador del móvil.
3. Sube los archivos y carpetas de este proyecto conservando su estructura.
4. En el repositorio, entra en **Actions** y permite ejecutar workflows si GitHub lo pide.
5. Ejecuta **Build KrinaOS prototype ISO**.
6. Cuando termine, abre la ejecución y descarga el artefacto `krinaos-iso-prototype`.

GitHub requiere una cuenta y conexión a Internet. No es necesario que el PC sin sistema operativo haga la compilación.

## Seguridad / instalación

No uses la ISO en el PC principal hasta comprobar que arranca y que el instalador no borra datos por defecto. Este proyecto no configura particionado automático. En el equipo real habrá que elegir manualmente el disco/partición de destino y verificarlo cuidadosamente.

## Portal al arrancar

El portal se abre en modo kiosco **después del inicio de sesión de Linux**. El primer arranque conserva el mecanismo normal de inicio de sesión; no se inventa una contraseña `Jynx`.
