const API = "http://127.0.0.1:8765/api";
const $ = (id) => document.getElementById(id);
const demo = {
  cpu: "Esperando servicio", cpu_detail: "No se inventan datos del equipo",
  ram: "—", ram_detail: "Conecta el servicio Linux", ram_percent: 0,
  disk: "—", disk_detail: "Conecta el servicio Linux", disk_percent: 0,
  net: "Sin comprobar", net_detail: "Vista previa", network_name: "Sin datos reales",
  network_state: "El servicio aún no está conectado", interface: "—", ip: "—", gateway: "—"
};
function setText(id, value) { $(id).textContent = value ?? "No disponible"; }
function notify(message) {
  const toast = $("toast"); toast.textContent = message; toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2600);
}
function render(data) {
  setText("cpu", data.cpu?.model || "CPU no disponible");
  setText("cpu-detail", data.cpu?.cores ? `${data.cpu.cores} núcleos lógicos` : "Información del procesador");
  setText("ram", data.memory ? `${data.memory.used_gb} / ${data.memory.total_gb} GB` : "—");
  setText("ram-detail", data.memory ? `${data.memory.percent}% utilizada` : "No disponible");
  $("ram-meter").style.width = `${Math.max(0, Math.min(100, data.memory?.percent || 0))}%`;
  setText("disk", data.disk ? `${data.disk.free_gb} GB libres` : "—");
  setText("disk-detail", data.disk ? `${data.disk.used_gb} de ${data.disk.total_gb} GB usados` : "No disponible");
  $("disk-meter").style.width = `${Math.max(0, Math.min(100, data.disk?.percent || 0))}%`;
  setText("net", data.network?.connected ? "Conectado" : "Estado desconocido");
  setText("net-detail", data.network?.connection || "No disponible");
  setText("network-name", data.network?.connection || "Red sin identificar");
  setText("network-state", data.network?.connected ? "Conexión activa" : "No se detectó conexión activa");
  setText("interface", data.network?.interface || "—");
  setText("ip", data.network?.ip || "—");
  setText("gateway", data.network?.gateway || "—");
  setText("wifi-count", data.network?.wifi_scan_supported ? "Consulta disponible en el sistema" : "No disponible en esta versión");
  setText("connection-label", "Servicio conectado");
  setText("updated", `Actualizado ${new Date().toLocaleTimeString()}`);
}
async function refresh() {
  try {
    const response = await fetch(`${API}/system`, { cache: "no-store" });
    if (!response.ok) throw new Error("Servicio no disponible");
    render(await response.json());
  } catch {
    setText("cpu", "Servicio desconectado");
    setText("cpu-detail", "La vista previa no puede leer hardware real");
    setText("connection-label", "Vista previa");
    setText("updated", "Sin conexión al servicio");
  }
}
async function loadFiles() {
  try {
    const response = await fetch(`${API}/files`, { cache: "no-store" });
    if (!response.ok) throw new Error("No se pudo cargar");
    const data = await response.json();
    const list = $("file-list"); list.replaceChildren();
    setText("folder-path", data.root || "Carpeta autorizada");
    if (!data.files.length) {
      list.innerHTML = '<div class="empty-state"><span>▤</span><strong>Carpeta vacía</strong><p>No hay archivos en la carpeta autorizada.</p></div>';
      return;
    }
    for (const file of data.files) {
      const row = document.createElement("div"); row.className = "detail-row";
      const name = document.createElement("span"); name.textContent = file.name;
      const size = document.createElement("strong"); size.textContent = file.is_dir ? "Carpeta" : `${file.size_kb} KB`;
      row.append(name, size); list.append(row);
    }
    notify("Lista de archivos actualizada.");
  } catch { notify("Servicio desconectado. No se han mostrado archivos."); }
}
$("refresh").addEventListener("click", refresh);
$("load-files").addEventListener("click", loadFiles);
refresh();
