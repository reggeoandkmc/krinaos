# KrinaOS — Portal personal

Portal local para **Ismael El Mounssi** con estética azul oscuro y cristal tipo iOS.

## Qué incluye este paquete

- `web/`: interfaz adaptable a ordenador y móvil.
- `service/`: servicio local de ejemplo en Python que muestra información real del equipo y estado de red.
- `systemd/`: ejemplo de unidad para arrancar el servicio al iniciar Linux.
- `docs/SEGURIDAD.md`: decisiones de seguridad y pasos pendientes.
- `docs/ARRANQUE_AUTOMATICO.md`: cómo hacer que se abra al iniciar sesión.

## Importante

Este paquete es el **proyecto fuente**, no una ISO ni un sistema operativo instalado. No puede leer hardware ni administrar archivos reales hasta ejecutar y configurar el servicio en un Linux compatible. No contiene contraseña de administrador: la autenticación real debe configurarse en el equipo y no guardarse en el HTML, JavaScript o repositorio.

La interfaz permite probar la vista previa sin servidor. Los datos reales se consultan a través del servicio local, una vez instalado.

## Vista previa desde Android

Abre `web/index.html` en un navegador o sirve la carpeta `web` desde un ordenador. La vista previa funciona con datos de ejemplo; los datos reales requieren el servicio.

## Servicio (Linux)

Requiere Python 3.10+ y Flask. En el equipo Linux, desde esta carpeta:

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r service/requirements.txt
python service/app.py
```

Por defecto escucha solo en `127.0.0.1:8765`, para evitar exponer el servicio a la red sin configuración. Para permitir acceso desde el móvil, consulta `docs/ACCESO_MOVIL.md` y `docs/SEGURIDAD.md` primero. No expongas este servicio directamente a Internet.

## Seguridad del gestor de archivos

El ejemplo del servicio solo enumera archivos dentro de una carpeta elegida por el usuario (`KRINA_FILES_ROOT`). No incluye subida/borrado remoto en esta versión inicial: antes hay que añadir autenticación real, protección CSRF, límites de tamaño y registro de actividad. No uses una interfaz web sin esas defensas para administrar archivos privados.

## Inicio automático

Consulta `docs/ARRANQUE_AUTOMATICO.md`. La página se puede abrir automáticamente al iniciar sesión en el escritorio. Mostrar el portal antes de iniciar sesión en Linux requiere una pantalla de login/kiosco especial y no debe sustituir el inicio de sesión seguro del sistema.


## Modo pantalla completa al arrancar
Se ha añadido `scripts/open-portal.sh`, `desktop/krinaos-portal.desktop` y `docs/ARRANQUE_PANTALLA_COMPLETA.md`. La idea es abrir el portal automáticamente a pantalla completa **después del inicio de sesión de Linux**. No salta UEFI ni reemplaza por sí solo el sistema operativo, y todavía requiere integrarse en la instalación/ISO final.
