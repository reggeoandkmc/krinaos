"""Servicio de lectura local para el portal KrinaOS.
Escucha en localhost por defecto. No implementa subida/borrado remoto.
"""
import os
import socket
from pathlib import Path

from flask import Flask, jsonify
import psutil

app = Flask(__name__)
FILES_ROOT = Path(os.environ.get("KRINA_FILES_ROOT", str(Path.home() / "KrinaFiles"))).expanduser().resolve()


def gb(value):
    return round(value / (1024 ** 3), 1)


def network_info():
    connection = "Sin conexión identificada"
    active_interface = None
    ip = None
    gateway = None
    try:
        stats = psutil.net_if_stats()
        addrs = psutil.net_if_addrs()
        for name, stat in stats.items():
            if stat.isup and name != "lo":
                for addr in addrs.get(name, []):
                    if addr.family == socket.AF_INET and not addr.address.startswith("127."):
                        active_interface, ip = name, addr.address
                        connection = f"Interfaz {name}"
                        break
                if ip:
                    break
    except Exception:
        pass
    # No se escanean redes cercanas ni se ejecutan comandos privilegiados en esta versión.
    return {
        "connected": bool(ip),
        "connection": connection,
        "interface": active_interface,
        "ip": ip,
        "gateway": gateway,
        "wifi_scan_supported": False,
    }


def system_info():
    vm = psutil.virtual_memory()
    disk_usage = psutil.disk_usage("/")
    cpu_model = "CPU no disponible"
    try:
        for line in Path("/proc/cpuinfo").read_text(errors="ignore").splitlines():
            if line.lower().startswith("model name"):
                cpu_model = line.split(":", 1)[1].strip()
                break
    except OSError:
        pass
    return {
        "cpu": {"model": cpu_model, "cores": psutil.cpu_count(logical=True)},
        "memory": {
            "total_gb": gb(vm.total),
            "used_gb": gb(vm.used),
            "percent": vm.percent,
        },
        "disk": {
            "total_gb": gb(disk_usage.total),
            "used_gb": gb(disk_usage.used),
            "free_gb": gb(disk_usage.free),
            "percent": disk_usage.percent,
        },
        "network": network_info(),
    }


@app.get("/api/system")
def api_system():
    return jsonify(system_info())


@app.get("/api/files")
def api_files():
    """Solo lista elementos inmediatos dentro de una carpeta configurada."""
    root = FILES_ROOT.resolve()
    root.mkdir(parents=True, exist_ok=True)
    result = []
    try:
        for entry in sorted(root.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))[:200]:
            resolved = entry.resolve()
            if root not in resolved.parents and resolved != root:
                continue
            try:
                result.append({
                    "name": entry.name,
                    "is_dir": entry.is_dir(),
                    "size_kb": round(entry.stat().st_size / 1024, 1) if entry.is_file() else None,
                })
            except OSError:
                continue
    except OSError:
        pass
    return jsonify({"root": str(root), "files": result})


if __name__ == "__main__":
    # Seguridad: localhost únicamente. No cambiar a 0.0.0.0 sin configurar
    # autenticación, TLS/HTTPS, firewall y protección CSRF.
    app.run(host="127.0.0.1", port=8765, debug=False)
